import { Program, std, shell } from "@tsix/Application";

export const main = Program(async () => {
  await std.println("Hello World!");

  const AST_UUID = "3ec3ffe9-e0a6-411f-b7e3-c9ff0b00556c";
  const title = "Test gui apps";
  const message = "Hello world";

  try {
    await shell.send(AST_UUID, {
      type: "DESKTOP_NOTIF",
      title,
      message,
      timestamp: Date.now(),
    });
  } catch (E) {}
});
