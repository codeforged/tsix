/**
 * ps-sample2.ts — PixelSpace Protocol Sample #2 (EMERALD)
 *
 * ============================================================
 * PENGANTAR PIXELSPACE (Tanpa Window Manager)
 * ============================================================
 *
 * PixelSpace adalah protokol display untuk TSIX (setara X11/Wayland).
 * Ia bekerja dengan DOM-Based Remote Rendering:
 *
 *   ┌──────────┐   GUI_REQ (61)   ┌────────┐   WebSocket   ┌──────────┐
 *   │  Worker   │ ──────────────► │ Kernel │ ────────────► │  Browser │
 *   │  (App)   │ ◄────────────── │ (Ring1)│ ◄──────────── │  (DOME)  │
 *   └──────────┘   IPC via SEND_MSG └────────┘   IBrowserEvent └──────────┘
 *
 * Alur minimal menampilkan elemen di browser:
 *
 *   1. CREATE_WINDOW   → Bikin jendela baru di browser
 *   2. MOUNT_NODE      → Pasang elemen (div, button, text) ke jendela
 *   3. UPDATE_PROPS    → Ubah properti elemen (misal: teks button setelah diklik)
 *   4. DESTROY_WINDOW  → Tutup jendela (cleanup)
 *
 * ───────────────────────────────────────────────────────────
 * PENDEKATAN: EMERALD — Screen + factory functions
 * ───────────────────────────────────────────────────────────
 *
 * Emerald adalah widget toolkit untuk PixelSpace — setara GTK/Qt.
 * `Screen` adalah wrapper tingkat tinggi untuk `Window`.
 *
 * Keuntungan pakai Screen:
 *   - Factory functions: div(), button(), text(), paragraph(), dll
 *   - Batching UPDATE_PROPS otomatis (tidak flood IPC)
 *   - Event handling: app.on("id", "click", cb)
 *   - Helper methods: app.setText(), app.setVisible(), app.hide(), dll
 *   - app.loopUntilClose() — no manual polling loop
 *   - Built-in alert() dan confirm() dialog
 *
 * Cocok untuk: aplikasi GUI sehari-hari
 *
 * Jalankan:  ps-sample2
 * PASTIKAN DOME SUDAH RUNNING:  dome
 * ============================================================
 */

import { Program, std, shell } from "@tsix/Application";
import { Screen, div, button, text, paragraph, span } from "@tsix/emerald";

async function mainEmerald(): Promise<void> {
  await std.log("═══════════════════════════════════════════");
  await std.log("[ps-sample2] ▸ Emerald Toolkit — Screen + factory functions");
  await std.log("═══════════════════════════════════════════");

  // ================================================================
  // 1️⃣ CREATE_WINDOW — via Screen constructor
  // ================================================================
  // new Screen({...}) secara internal:
  //   1. new Window({...}) — yang kirim GUI_REQ CREATE_WINDOW
  //   2. Generate UUID untuk wid (window ID)
  //   3. Set up event listener untuk terima event dari DOME
  //   4. Notifikasi parent process (Asteracea) bahwa window dibuat
  //
  // Opsional: fullscreen, frameless, maximizable, resizable
  const app = new Screen({
    title: "ps-sample2 — Emerald Toolkit",
    width: 480,
    height: 320,
    maximizable: false,
    resizable: true,
  });
  await std.log(`  ✓ CREATE_WINDOW → wid: ${app.wid}`);

  // ================================================================
  // 2️⃣ MOUNT_NODE — via app.mount() dengan factory functions
  // ================================================================
  // Factory functions (div, button, text, paragraph, dll) membangun
  // IDOMNode tree secara otomatis — { id, tag, props, children }.
  //
  // app.mount(node) → Window.mount(node) → GUI_REQ MOUNT_NODE
  //
  // Tidak perlu manual makeNode() seperti ps-sample1!
  await app.mount(
    // root container — semua elemen di-mount ke sini
    div({ id: "root", style: { padding: "24px", fontFamily: "sans-serif" } },

      // ── Header ──
      paragraph({
        id: "title",
        text: "🎨 PixelSpace + Emerald Toolkit",
        style: { fontSize: "20px", fontWeight: "bold", margin: "0 0 4px 0", color: "#4caf50" },
      }),

      // ── Penjelasan ──
      paragraph({
        id: "subtitle",
        text: "Button dikirim via GUI_REQ → MOUNT_NODE → WebSocket → DOM",
        style: { fontSize: "12px", color: "#888", margin: "0 0 16px 0" },
      }),

      // ── Tombol interaktif ──
      // onClickId akan di-set otomatis oleh app.on("click") di langkah 3.
      // props: text, style, id (wajib!), className, disabled, dll
      button({
        id: "btn-click",
        text: "🔘 Klik Saya!",
        style: {
          background: "#4caf50", color: "white",
          border: "none", padding: "10px 24px",
          borderRadius: "6px", cursor: "pointer",
          fontSize: "14px", fontWeight: "600",
          transition: "all 0.2s ease",
        },
      }),

      // ── Status text ──
      paragraph({
        id: "status",
        text: "⏳ Belum diklik",
        style: { marginTop: "16px", fontSize: "13px", color: "#aaa", fontStyle: "italic" },
      }),

      // ── Counter (akan di-update setiap klik) ──
      paragraph({
        id: "counter",
        text: "Klik: 0",
        style: { marginTop: "8px", fontSize: "13px", color: "#888" },
      }),
    ),
  );
  await std.log("  ✓ MOUNT_NODE — UI tree terpasang (div › p×3 + button + p×2)");

  // ================================================================
  // 3️⃣ Event Handler — binding klik
  // ================================================================
  // app.on(targetId, eventType, callback):
  //   1. Panggil Window.onClick() → kirim UPDATE_PROPS (onClickId)
  //   2. Daftarkan callback
  //   3. Saat browser klik → DOME → Kernel → Worker → callback jalan
  //
  // app.setText(id, text) — shortcut untuk updateProps({ text })
  // app.update(id, props) — langsung panggil updateProps

  let clickCount = 0;

  await app.on("btn-click", "click", async () => {
    clickCount++;
    await std.log(`  ✦ Button diklik! (${clickCount}x)`);

    // Update teks button — setelah klik pertama
    if (clickCount === 1) {
      await app.update("btn-click", {
        text: "✅ Sudah Diklik!",
        style: {
          background: "#2196f3", color: "white",
          border: "none", padding: "10px 24px",
          borderRadius: "6px", cursor: "pointer",
          fontSize: "14px", fontWeight: "600",
        },
      });
    }

    // Update status text — pakai helper setText()
    await app.setText("status", `✅ Diklik! Event sampai di Worker via IPC.`);

    // Update counter
    await app.setText("counter", `Klik: ${clickCount}`);
  });

  // ================================================================
  // 4️⃣ Stay alive sampai window ditutup
  // ================================================================
  // loopUntilClose() secara internal:
  //   1. Daftarkan onClose handler → set running = false
  //   2. Polling setiap 1 detik (while running)
  //   3. Saat loop selesai, panggil Window.close()
  //
  // Tidak perlu manual while() seperti ps-sample1!
  await std.log("  ✓ Menunggu interaksi user. Tutup window untuk exit.");
  await app.loopUntilClose();

  await std.log("  ✓ DESTROY_WINDOW — window ditutup.");
}


// ================================================================
// MAIN
// ================================================================
export const appMode = "gui";

export const main = Program(async (args: string[]) => {
  // Cek koneksi ke DOME
  try {
    const domeuuid = "da8711c2-5ca9-4f00-ad13-f1226f95594c";
    await shell.send(domeuuid, { type: "ping" });
    await std.log("  ✓ DOME merespon");
  } catch (e) {
    await std.error("[ps-sample2] ❌ DOME tidak merespon. Jalankan 'dome' dulu!");
    return;
  }

  await mainEmerald();

  await std.log("");
  await std.log("[ps-sample2] Selesai ✅");
});
