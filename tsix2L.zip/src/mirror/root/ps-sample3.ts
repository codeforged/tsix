/**
 * ps-sample3.ts — PixelSpace Protocol Sample #3 (EMERALD — DINAMIS)
 *
 * ============================================================
 * MATERI BARU DI SAMPLE INI
 * ============================================================
 *
 * ps-sample1 → Raw protocol (CREATE_WINDOW, MOUNT_NODE, UPDATE_PROPS)
 * ps-sample2 → Emerald dasar (Screen, mount, onClick, setText)
 *
 * ps-sample3 → Emerald DINAMIS — pola yang dipakai aplikasi sungguhan:
 *
 *   1. setContent()   — ganti isi container secara dinamis (list!)
 *                       Konsep: "clear dulu, isi ulang" — GAK NUMPUK.
 *                       Ini pola inti file-cruiser, task list, chat, dll.
 *
 *   2. MOUNT-TIME LISTENERS — ⭐ PELAJARAN PENTING DARI BUG:
 *      onInputId / onKeydownId / onClickId dipasang LANGSUNG di props
 *      saat mount, BUKAN via app.on() setelah mount.
 *
 *      Kenapa? app.on() mengirim UPDATE_PROPS onXxxId, dan handleUpdateProps
 *      di DOME melakukan cloneNode (ganti elemen). cloneNode TIDAK menyalin
 *      listener lama → kalau satu elemen di-register 2x (input + keydown),
 *      listener pertama HILANG. Pasang di mount = semua listener menempel
 *      sekaligus, tanpa clone.
 *
 *   3. bindHandler()  — daftarkan callback di Worker TANPA UPDATE_PROPS.
 *      Pasangan sempurna untuk mount-time listeners (lihat pola gui-demo).
 *
 *   4. Re-bind events — PENTING! Setelah setContent(), node baru belum punya
 *      callback → bind ulang via bindHandler (listener browser sudah ada
 *      karena onClickId di props mount).
 *
 *   5. setVisible     — show/hide elemen (empty state)
 *
 * Aplikasi: TODO LIST sederhana.
 *   - Ketik di input → Enter / tombol Add → item masuk list
 *   - Klik item → dihapus
 *   - Empty state muncul saat list kosong
 *
 * Jalankan:  ps-sample3
 * PASTIKAN DOME SUDAH RUNNING:  dome
 * ============================================================
 */

import { Program, std, shell } from "@tsix/Application";
import {
  Screen, div, button, input, text, paragraph, span,
} from "@tsix/emerald";
import { theme } from "@tsix/theme";

async function mainTodo(): Promise<void> {
  await std.log("═══════════════════════════════════════════");
  await std.log("[ps-sample3] ▸ Emerald Dinamis — Todo List");
  await std.log("═══════════════════════════════════════════");

  // Load theme aktif (terang/gelap) — otomatis ikut prefs Asteracea
  await theme.loadCurrent();
  theme.watch();

  const app = new Screen({
    title: "ps-sample3 — Todo List",
    width: 520,
    height: 480,
    maximizable: false,
    resizable: true,
  });
  await std.log(`  ✓ CREATE_WINDOW → wid: ${app.wid}`);

  // ================================================================
  // STATE — data yang dipegang Worker (bukan browser!)
  // ================================================================
  // Penting: UI di browser itu "bayangan". DATA ASLI ada di sini.
  // setContent() selalu rebuild UI dari state ini.
  interface TodoItem { id: number; text: string; }
  const todos: TodoItem[] = [];
  let nextId = 1;

  // Nilai input terbaru — variabel lokal (pola gui-demo.ts)
  // Bukan app.state: lebih simpel & tidak bergantung getter/setter.
  let inputTask = "";

  // ================================================================
  // MOUNT — struktur tetap (static shell)
  // ================================================================
  // Yang STATIC di-mount sekali: input, tombol add, header, counter.
  // Yang DINAMIS (list item) ada di container #list-container —
  //   isinya di-rebuild terus via setContent().
  await app.mount(
    div({ id: "root", style: { padding: "20px", fontFamily: "sans-serif", height: "100%", boxSizing: "border-box", background: theme.colors.bg, color: theme.colors.text } },

      // ── Header ──
      paragraph({
        id: "title",
        text: "📝 PixelSpace Todo List",
        style: { fontSize: "20px", fontWeight: "bold", margin: "0 0 4px 0", color: theme.colors.accent },
      }),
      paragraph({
        id: "subtitle",
        text: "setContent() + onInput + onKeydown + re-bind events",
        style: { fontSize: "12px", color: theme.colors.textMuted, margin: "0 0 16px 0" },
      }),

      // ── Input bar: input + tombol add ──
      // ⚠️ PENTING: onInputId/onKeydownId/onClickId dipasang LANGSUNG
      //    di props saat mount — BUKAN via app.on() nanti.
      //
      // Kenapa? Karena app.on() mengirim UPDATE_PROPS onInputId/onKeydownId,
      // dan handleUpdateProps di DOME melakukan cloneNode → GANTI elemen.
      // cloneNode TIDAK menyalin listener lama → listener pertama HILANG.
      // Dengan pasang di mount, semua listener menempel sekaligus.
      div({ id: "input-bar", style: { display: "flex", gap: "8px", marginBottom: "12px" } },
        input({
          id: "input-task",
          type: "text",
          placeholder: "Ketik tugas...",
          onInputId: "input-task",     // ← mount-time: listener input
          onKeydownId: "input-task",   // ← mount-time: listener keydown
          style: {
            flex: "1", padding: "8px 12px", borderRadius: "6px",
            border: `1px solid ${theme.colors.inputBorder}`,
            background: theme.colors.inputBg,
            color: theme.colors.text,
            fontSize: "14px",
          },
        }),
        button({
          id: "btn-add",
          text: "➕ Add",
          onClickId: "btn-add",        // ← mount-time: listener click
          style: {
            background: theme.colors.accent, color: "#fff", border: "none",
            padding: "8px 18px", borderRadius: "6px", cursor: "pointer",
            fontSize: "14px", fontWeight: "600",
          },
        }),
      ),

      // ── Counter (di-update tiap tambah/hapus) ──
      paragraph({
        id: "counter",
        text: "0 tugas",
        style: { fontSize: "12px", color: theme.colors.textMuted, margin: "0 0 8px 0" },
      }),

      // ── Dynamic list container ──
      // Isi container INI yang di-rebuild via setContent()
      div({
        id: "list-container",
        style: {
          borderTop: `1px solid ${theme.colors.border}`, paddingTop: "12px",
          maxHeight: "260px", overflowY: "auto",
        },
      }),
    ),
  );
  await std.log("  ✓ Static shell mounted");

  // ================================================================
  // RENDER LIST — fungsi inti yang rebuild isi #list-container
  // ================================================================
  async function renderList(): Promise<void> {
    // 1️⃣ Update counter
    await app.setText("counter", `${todos.length} tugas`);

    // 2️⃣ Kalau kosong → tampilkan empty state, sembunyikan list
    if (todos.length === 0) {
      await app.setVisible("empty-state", true);
      await app.setContent("list-container");  // clear container (tanpa child)
      await app.setVisible("list-container", false);
      return;
    }

    // 3️⃣ Bangun baris-baris dari state
    const rows = todos.map((item) =>
      div(
        {
          id: `todo-${item.id}`,
          onClickId: `todo-${item.id}`,  // ← agar browser pasang listener klik
          style: {
            display: "flex", justifyContent: "space-between", alignItems: "center",
            padding: "8px 12px", marginBottom: "6px", borderRadius: "6px",
            color: theme.colors.text,
            background: theme.colors.card, border: `1px solid ${theme.colors.border}`, cursor: "pointer",
            fontSize: "14px",
          },
        },
        // Teks item (pake text() agar jadi TextNode)
        text(item.text),
        // Tombol hapus kecil
        span({ text: "✕", style: { color: theme.colors.danger, fontSize: "12px", marginLeft: "8px" } }),
      ),
    );

    // 4️⃣ setContent: clear + isi ulang dalam satu operasi atomik
    //    (internal: UPDATE_PROPS innerHTML="" lalu MOUNT_NODE per child)
    await app.setContent("list-container", ...rows);
    await app.setVisible("list-container", true);
    await app.setVisible("empty-state", false);

    // 5️⃣ RE-BIND EVENTS — WAJIB! Node yang baru di-mount belum punya handler.
    //    Karena onClickId sudah ada di props mount (baris atas), cukup
    //    daftarkan callback via bindHandler — TANPA UPDATE_PROPS/clone.
    //    (Node lama sudah dibuang setContent, listener lama ikut mati.)
    todos.forEach((item) => {
      app.win.bindHandler(`todo-${item.id}`, "click", async () => {
        await removeTodo(item.id);
      });
    });
  }

  // ================================================================
  // TAMBAH & HAPUS
  // ================================================================
  async function addTodo(textValue: string): Promise<void> {
    const trimmed = textValue.trim();
    if (!trimmed) return;

    todos.push({ id: nextId++, text: trimmed });
    await std.log(`  ✚ Add: "${trimmed}" (total ${todos.length})`);

    // Kosongkan input (browser) + reset tracker lokal (Worker)
    await app.setText("input-task", "");
    inputTask = "";

    await renderList();                     // rebuild list
  }

  async function removeTodo(id: number): Promise<void> {
    const idx = todos.findIndex((t) => t.id === id);
    if (idx === -1) return;

    const [removed] = todos.splice(idx, 1);
    await std.log(`  ✖ Remove: "${removed.text}" (sisa ${todos.length})`);
    await renderList();
  }

  // ================================================================
  // EVENT BINDING (static elements)
  // ================================================================
  // ⚠️ Kita pakai app.win.bindHandler() — BUKAN app.on().
  //
  // Kenapa? Karena listener (onClickId/onInputId/onKeydownId) sudah
  // dipasang saat MOUNT di props. app.on() akan mengirim UPDATE_PROPS
  // yang memicu cloneNode di DOME → listener lama hilang.
  //
  // bindHandler() hanya mendaftarkan callback di Worker TANPA
  // mengirim UPDATE_PROPS — pasangan sempurna untuk mount-time props.

  // ── 1. Tombol Add → klik ──
  app.win.bindHandler("btn-add", "click", async () => {
    await addTodo(inputTask);   // baca variabel lokal (di-update handler input)
  });

  // ── 2. Input → onInput: simpan teks terbaru ──
  //    ev.value berisi teks terbaru dari input (pola gui-demo.ts:
  //    guard ev.value !== undefined lalu assign ke variabel lokal)
  app.win.bindHandler("input-task", "input", (ev: any) => {
    if (ev.value !== undefined) inputTask = String(ev.value);
  });

  // ── 3. Input → onKeydown: tekan Enter = tambah ──
  //    ev.value berisi key yang ditekan ("Enter", "Tab", "a", dll)
  app.win.bindHandler("input-task", "keydown", (ev: any) => {
    if (ev.value === "Enter") {
      void addTodo(inputTask);
    }
  });

  // ── 4. Empty state — di-mount terakhir agar jadi child #list-container,
  //       lalu disembunyikan. (atau mount di root, kita pilih di root bawah)
  await app.mount(
    div({
      id: "empty-state",
      style: {
        display: "none",  // mulai tersembunyi
        padding: "24px", textAlign: "center", color: theme.colors.textMuted,
        fontSize: "13px", fontStyle: "italic", border: `1px dashed ${theme.colors.border}`,
        borderRadius: "8px",
      },
    },
      text("Belum ada tugas. Ketik di atas lalu tekan Enter ✨"),
    ),
  );

  // ================================================================
  // WAIT — stay alive
  // ================================================================
  await std.log("  ✓ Todo list siap! Ketik tugas + Enter untuk mencoba.");
  await app.loopUntilClose();
  await std.log("  ✓ Window ditutup.");
}


// ================================================================
// MAIN
// ================================================================
export const appMode = "gui";

export const main = Program(async (args: string[]) => {
  await std.log("╔══════════════════════════════════════════╗");
  await std.log("║  ps-sample3 — Emerald Dinamis (Todo)     ║");
  await std.log("║  setContent + input + keydown + re-bind  ║");
  await std.log("╚══════════════════════════════════════════╝");

  try {
    const domeuuid = "da8711c2-5ca9-4f00-ad13-f1226f95594c";
    await shell.send(domeuuid, { type: "ping" });
    await std.log("  ✓ DOME merespon");
  } catch (e) {
    await std.error("[ps-sample3] ❌ DOME tidak merespon. Jalankan 'dome' dulu!");
    return;
  }

  await mainTodo();

  await std.log("");
  await std.log("[ps-sample3] Selesai ✅");
});
