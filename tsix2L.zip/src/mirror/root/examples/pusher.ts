import { UserLib } from "@tsix/UserLib";

export default class IPCPusher {
    async execute(lib: UserLib, args: string[]) {
        if (args.length < 2) {
            await lib.std.println("Usage: pusher.ts <target_pid> <message>");
            return;
        }

        const targetPid = parseInt(args[0]);
        const message = args.slice(1).join(" ");

        await lib.std.print(`[Pusher] Sending to PID ${targetPid}: "${message}"... `);

        try {
            // Kita bungkus ke dalam object biar keren
            const success = await lib.shell.send(targetPid, {
                content: message,
                type: "test_ipc",
                timestamp: new Date().toLocaleTimeString()
            });

            if (success) {
                await lib.std.print("Done! (Check the listener output)\n");
            } else {
                await lib.std.print("FAILED! (Is the target PID correct?)\n");
            }
        } catch (e: any) {
            await lib.std.print(`ERROR: ${e.message}\n`);
        }
    }
}
