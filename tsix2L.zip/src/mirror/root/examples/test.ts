import { IProgram, OSContext } from "../lib/IProgram";

/**
 * ATTO Text Editor
 * Ported from NOS for TS-Linux.
 * Robust implementation matching texteditor.js logic.
 */

interface EditorState {
    lines: string[];
    cursorX: number;
    cursorY: number;
    offsetX: number;
    offsetY: number;
    monoPos: number;
}

class SimpleTextEditor {
    public lines: string[];
    public cursorX: number = 0;
    public cursorY: number = 0;
    public offsetX: number = 0;
    public offsetY: number = 0;
    public monoPos: number = 0;
    public screenWidth: number = 80;
    public screenHeight: number = 23;
    public changed: boolean = false;
    public filename: string;
    private os: OSContext;

    private originalLines: string[] = [];

    // Search & Replace state
    private findMode: boolean = false;
    private findText: string = "";
    private replaceMode: boolean = false;
    private replaceText: string = "";
    private findResults: { line: number, col: number, length: number }[] = [];
    private findCurrentIndex: number = -1;
    private findStep: "find" | "replace" | "confirm" = "find";

    private undoStack: EditorState[] = [];
    private redoStack: EditorState[] = [];
    private maxHistorySize: number = 50;
    private lastEditLine: number = -1;
    private lastEditCol: number = -1;

    constructor(content: string, os: OSContext, filename: string) {
        this.os = os;
        this.filename = filename;
        content = content.replace(/\t/g, "  ");
        this.lines = content ? content.split("\n") : [""];
        this.originalLines = [...this.lines];
    }

    public async init() {
        const screen = await this.os.std.getScreenInfo() || { lines: 24, columns: 80 };
        this.screenWidth = screen.columns;
        this.screenHeight = screen.lines - 1; // Reserve 1 for status bar
    }

    /**
     * RENDER UI
     */
    public async render() {
        const { std } = this.os;
        const visibleLines = this.lines.slice(this.offsetY, this.offsetY + this.screenHeight);

        let output = "\x1B[?25l"; // Hide cursor
        for (let i = 0; i < this.screenHeight; i++) {
            const line = visibleLines[i] || "";
            const displayLine = line.slice(this.offsetX, this.offsetX + this.screenWidth);
            output += `\x1b[${i + 1};1H\x1b[2K${displayLine}`;

            if (line.length > this.offsetX + this.screenWidth) {
                output += `\x1b[${i + 1};${this.screenWidth}H→`;
            }
        }

        await std.print(output);
        await this.renderStatusBar();
        await this.renderCursorOnly();
    }

    public async renderStatusBar() {
        const { std } = this.os;

        if (this.findMode) {
            let prompt = "";
            if (this.findStep === "find") prompt = `Find: ${this.findText}`;
            else if (this.findStep === "replace") prompt = `Replace with: ${this.replaceText}`;
            else if (this.findStep === "confirm") prompt = `Replace ALL ${this.findResults.length} occurrences? (a)ll (c)ancel`;

            const padding = " ".repeat(Math.max(0, this.screenWidth - prompt.length));
            await std.print(`\x1b[${this.screenHeight + 1};1H\x1b[47m\x1b[30m${prompt}${padding}\x1b[0m`);
            return;
        }

        const totalLines = this.lines.length;
        const currentLine = this.cursorY + this.offsetY + 1;
        const currentCol = this.cursorX + 1;
        const modified = this.changed ? " [Modified]" : "";

        const leftText = ` R:${currentLine}/${totalLines} C:${currentCol}${modified} `;
        const rightText = ` ${this.filename} `;
        const paddingCount = Math.max(0, this.screenWidth - leftText.length - rightText.length);
        const padding = " ".repeat(paddingCount);

        const statusOutput = `\x1b[${this.screenHeight + 1};1H\x1b[47m\x1b[30m${leftText}${padding}${rightText}\x1b[0m`;
        await std.print(statusOutput);
    }

    public async renderCursorOnly() {
        if (this.findMode) {
            let cursorCol = 1;
            if (this.findStep === "find") cursorCol = 7 + this.findText.length;
            else if (this.findStep === "replace") cursorCol = 15 + this.replaceText.length;
            else if (this.findStep === "confirm") cursorCol = this.screenWidth;
            await this.os.std.print(`\x1b[${this.screenHeight + 1};${cursorCol}H\x1B[?25h`);
            return;
        }
        const displayCursorX = Math.max(0, Math.min(this.screenWidth - 1, this.cursorX - this.offsetX));
        await this.os.std.print(`\x1b[${this.cursorY + 1};${displayCursorX + 1}H\x1B[?25h`);
    }

    /**
     * INPUT HANDLING
     */
    public async handleKey(char: string): Promise<string | void> {
        const { std } = this.os;

        if (char === "\u001b") { // Escape sequences
            const seq1 = await std.getChar();
            if (seq1 === "[") {
                const seq2 = await std.getChar();
                if (seq2 === "A") await this.moveUp();
                else if (seq2 === "B") await this.moveDown();
                else if (seq2 === "C") await this.moveRight();
                else if (seq2 === "D") await this.moveLeft();
                else if (seq2 === "H") await this.jumpToHome();
                else if (seq2 === "F") await this.jumpToEnd();
                else if (seq2 === "5") { await std.getChar(); await this.pageUp(); }
                else if (seq2 === "6") { await std.getChar(); await this.pageDown(); }
                else if (seq2 === "3") { await std.getChar(); await this.deleteChar(); }
                else if (seq2 === "1") {
                    const seq3 = await std.getChar();
                    if (seq3 === ";") {
                        const seq4 = await std.getChar();
                        if (seq4 === "5") { // Ctrl+Arrow
                            const seq5 = await std.getChar();
                            if (seq5 === "C") await this.jumpToNextWord();
                            else if (seq5 === "D") await this.jumpToPrevWord();
                        }
                    }
                }
            } else if (seq1 === "O") {
                const seq2 = await std.getChar();
                if (seq2 === "P") { // F1: Help
                    await this.showHelp();
                }
            } else if (seq1 === "r") { // Alt+R: Replace
                await this.startFindMode(true);
            }
            return;
        }

        // Global Shortcuts
        if (char === "\u0006") { // Ctrl+F: Find
            await this.startFindMode(false);
            return;
        }
        if (char === "\u000c") { // Ctrl+L: Find Next
            await this.findNext();
            return;
        }
        if (char === "\u0012") { // Ctrl+R: Replace
            await this.startFindMode(true);
            return;
        }
        if (char === "\u0013") { // Ctrl+S: Save
            await this.save();
            return;
        }
        if (char === "\u0017") { // Ctrl+W: Save & Exit
            if (this.changed) {
                const choice = await this.askDirtyExit();
                if (choice === "save") { await this.save(); return "exit"; }
                if (choice === "discard") return "exit";
                if (choice === "cancel") { await this.render(); return; }
            }
            await this.save();
            return "exit";
        }
        if (char === "\u0003") { // Ctrl+C: Exit
            if (this.changed) {
                const choice = await this.askDirtyExit();
                if (choice === "save") { await this.save(); return "exit"; }
                if (choice === "discard") return "exit";
                if (choice === "cancel") { await this.render(); return; }
            }
            return "exit";
        }
        if (char === "\u001a") { // Ctrl+Z: Undo
            this.undo();
            await this.render();
            return;
        }
        if (char === "\u0019") { // Ctrl+Y: Redo
            this.redo();
            await this.render();
            return;
        }

        // Mode-specific input
        if (this.findMode) {
            if (char === "\r" || char === "\n") {
                if (this.findStep === "find") {
                    if (this.findText) {
                        this.performFind();
                        if (this.findResults.length > 0) {
                            if (this.replaceMode) {
                                this.findStep = "replace";
                                await this.renderStatusBar();
                            } else {
                                this.findMode = false;
                                await this.jumpToResult(0);
                            }
                        } else {
                            await this.os.std.print(`\x1b[${this.screenHeight + 1};1H\x1b[41m\x1b[37m No results found for "${this.findText}" \x1b[0m\x1b[K`);
                            setTimeout(() => this.renderStatusBar(), 2000);
                        }
                    } else {
                        this.findMode = false;
                        await this.render();
                    }
                } else if (this.findStep === "replace") {
                    this.findStep = "confirm";
                    await this.renderStatusBar();
                }
                return;
            }
            if (char === "\u001b") { // Esc to cancel
                this.findMode = false;
                this.replaceMode = false;
                await this.render();
                return;
            }
            if (this.findStep === "confirm") {
                const c = char.toLowerCase();
                if (c === "a") { await this.replaceAll(); this.findMode = false; }
                else if (c === "c" || char === "\u001b") { this.findMode = false; await this.render(); }
                return;
            }

            if (char === "\u007f" || char === "\b") {
                if (this.findStep === "find") this.findText = this.findText.slice(0, -1);
                else if (this.findStep === "replace") this.replaceText = this.replaceText.slice(0, -1);
                await this.renderStatusBar();
            } else if (char >= " ") {
                if (this.findStep === "find") this.findText += char;
                else if (this.findStep === "replace") this.replaceText += char;
                await this.renderStatusBar();
            }
            return;
        }

        // Regular Editing
        if (char === "\r" || char === "\n") {
            this.captureState(true);
            const currentLineIdx = this.cursorY + this.offsetY;
            const currentLine = this.lines[currentLineIdx];
            this.lines.splice(currentLineIdx + 1, 0, currentLine.slice(this.cursorX));
            this.lines[currentLineIdx] = currentLine.slice(0, this.cursorX);
            this.cursorX = 0;
            this.offsetX = 0;
            if (this.cursorY < this.screenHeight - 1) this.cursorY++;
            else this.offsetY++;
            this.changed = true;
            this.monoPos = 0;
            this.checkModified();
            await this.render();
        } else if (char === "\u007f" || char === "\b") {
            await this.backspace();
            await this.render();
        } else if (char >= " ") {
            this.captureState();
            const lineIdx = this.cursorY + this.offsetY;
            const line = this.lines[lineIdx] || "";
            this.lines[lineIdx] = line.slice(0, this.cursorX) + char + line.slice(this.cursorX);
            this.cursorX++;
            this.changed = true;
            this.monoPos = this.cursorX;
            this.checkModified();
            await this.adjustHorizontalScroll();
            await this.renderCursorOnly();
        }
    }

    /**
     * NAVIGATION
     */
    private async moveUp() {
        if (this.cursorY > 0) {
            this.cursorY--;
        } else if (this.offsetY > 0) {
            this.offsetY--;
            await this.render();
        }
        const line = this.lines[this.cursorY + this.offsetY] || "";
        this.cursorX = Math.min(this.monoPos, line.length);
        await this.adjustHorizontalScroll();
        await this.renderCursorOnly();
    }

    private async moveDown() {
        if (this.cursorY < this.screenHeight - 1 && this.cursorY + this.offsetY < this.lines.length - 1) {
            this.cursorY++;
        } else if (this.offsetY + this.screenHeight < this.lines.length) {
            this.offsetY++;
            await this.render();
        }
        const line = this.lines[this.cursorY + this.offsetY] || "";
        this.cursorX = Math.min(this.monoPos, line.length);
        await this.adjustHorizontalScroll();
        await this.renderCursorOnly();
    }

    private async moveLeft() {
        if (this.cursorX > 0) {
            this.cursorX--;
            this.monoPos = this.cursorX;
            await this.adjustHorizontalScroll();
            await this.renderCursorOnly();
        } else if (this.cursorY + this.offsetY > 0) {
            await this.moveUp();
            this.cursorX = this.lines[this.cursorY + this.offsetY].length;
            this.monoPos = this.cursorX;
            await this.adjustHorizontalScroll();
            await this.render();
        }
    }

    private async moveRight() {
        const line = this.lines[this.cursorY + this.offsetY] || "";
        if (this.cursorX < line.length) {
            this.cursorX++;
            this.monoPos = this.cursorX;
            await this.adjustHorizontalScroll();
            await this.renderCursorOnly();
        } else if (this.cursorY + this.offsetY < this.lines.length - 1) {
            await this.moveDown();
            this.cursorX = 0;
            this.offsetX = 0;
            this.monoPos = 0;
            await this.render();
        }
    }

    private async jumpToHome() {
        this.cursorX = 0;
        this.offsetX = 0;
        this.monoPos = 0;
        await this.renderCursorOnly();
    }

    private async jumpToEnd() {
        const line = this.lines[this.cursorY + this.offsetY] || "";
        this.cursorX = line.length;
        this.monoPos = this.cursorX;
        await this.adjustHorizontalScroll();
        await this.render();
    }

    private async pageUp() {
        this.offsetY = Math.max(0, this.offsetY - this.screenHeight);
        await this.render();
    }

    private async pageDown() {
        if (this.offsetY + this.screenHeight < this.lines.length) {
            this.offsetY = Math.min(this.lines.length - this.screenHeight, this.offsetY + this.screenHeight);
            await this.render();
        }
    }

    private async jumpToNextWord() {
        const line = this.lines[this.cursorY + this.offsetY] || "";
        if (this.cursorX >= line.length) {
            if (this.cursorY + this.offsetY < this.lines.length - 1) {
                await this.moveDown();
                this.cursorX = 0;
                this.monoPos = 0;
                await this.render();
            }
            return;
        }
        let pos = this.cursorX;
        const isAlphanum = (c: string) => /[a-zA-Z0-9]/.test(c);
        if (isAlphanum(line[pos])) {
            while (pos < line.length && isAlphanum(line[pos])) pos++;
        }
        while (pos < line.length && !isAlphanum(line[pos])) pos++;
        this.cursorX = pos;
        this.monoPos = pos;
        await this.adjustHorizontalScroll();
        await this.render();
    }

    private async jumpToPrevWord() {
        if (this.cursorX === 0) {
            if (this.cursorY + this.offsetY > 0) {
                await this.moveUp();
                this.cursorX = this.lines[this.cursorY + this.offsetY].length;
                this.monoPos = this.cursorX;
                await this.render();
            }
            return;
        }
        const line = this.lines[this.cursorY + this.offsetY] || "";
        let pos = this.cursorX - 1;
        const isAlphanum = (c: string) => /[a-zA-Z0-9]/.test(c);
        while (pos > 0 && !isAlphanum(line[pos])) pos--;
        while (pos > 0 && isAlphanum(line[pos - 1])) pos--;
        this.cursorX = pos;
        this.monoPos = pos;
        await this.adjustHorizontalScroll();
        await this.render();
    }

    private async adjustHorizontalScroll() {
        const margin = 5;
        if (this.cursorX < this.offsetX + margin) {
            this.offsetX = Math.max(0, this.cursorX - margin);
            await this.render();
        } else if (this.cursorX >= this.offsetX + this.screenWidth - margin) {
            this.offsetX = this.cursorX - this.screenWidth + margin + 1;
            await this.render();
        }
    }

    /**
     * EDITING ACTIONS
     */
    private async backspace() {
        if (this.cursorX > 0) {
            this.captureState();
            const lineIdx = this.cursorY + this.offsetY;
            const line = this.lines[lineIdx];
            this.lines[lineIdx] = line.slice(0, this.cursorX - 1) + line.slice(this.cursorX);
            this.cursorX--;
            this.changed = true;
            this.monoPos = this.cursorX;
            this.checkModified();
            await this.adjustHorizontalScroll();
        } else if (this.cursorY + this.offsetY > 0) {
            this.captureState();
            const currentLineIdx = this.cursorY + this.offsetY;
            const prevLineIdx = currentLineIdx - 1;
            const prevLine = this.lines[prevLineIdx];
            this.cursorX = prevLine.length;
            this.lines[prevLineIdx] = prevLine + this.lines[currentLineIdx];
            this.lines.splice(currentLineIdx, 1);
            if (this.cursorY > 0) this.cursorY--;
            else this.offsetY--;
            this.changed = true;
            this.monoPos = this.cursorX;
            this.checkModified();
            await this.adjustHorizontalScroll();
        }
    }

    private async deleteChar() {
        const lineIdx = this.cursorY + this.offsetY;
        const line = this.lines[lineIdx];
        if (this.cursorX < line.length) {
            this.captureState();
            this.lines[lineIdx] = line.slice(0, this.cursorX) + line.slice(this.cursorX + 1);
            this.changed = true;
            this.checkModified();
            await this.render();
        } else if (lineIdx < this.lines.length - 1) {
            this.captureState();
            this.lines[lineIdx] = line + this.lines[lineIdx + 1];
            this.lines.splice(lineIdx + 1, 1);
            this.changed = true;
            this.checkModified();
            await this.render();
        }
    }

    /**
     * STATE MANAGEMENT
     */
    private captureState(force: boolean = false) {
        const currLineIdx = this.cursorY + this.offsetY;
        const currCol = this.cursorX;

        if (!force) {
            if (this.lastEditLine === currLineIdx) {
                const line = this.lines[currLineIdx] || "";
                if (Math.abs(currCol - this.lastEditCol) < 2) {
                    const min = Math.min(this.lastEditCol, currCol);
                    const max = Math.max(this.lastEditCol, currCol);
                    const between = line.substring(min, max);
                    if (between.indexOf(" ") === -1 && between.indexOf("\t") === -1) return;
                }
            }
        }

        this.lastEditLine = currLineIdx;
        this.lastEditCol = currCol;

        if (this.undoStack.length >= this.maxHistorySize) this.undoStack.shift();
        this.undoStack.push({
            lines: [...this.lines],
            cursorX: this.cursorX,
            cursorY: this.cursorY,
            offsetX: this.offsetX,
            offsetY: this.offsetY,
            monoPos: this.monoPos
        });
        this.redoStack = [];
    }

    private undo() {
        if (this.undoStack.length === 0) return;
        this.redoStack.push({
            lines: [...this.lines],
            cursorX: this.cursorX,
            cursorY: this.cursorY,
            offsetX: this.offsetX,
            offsetY: this.offsetY,
            monoPos: this.monoPos
        });
        const state = this.undoStack.pop()!;
        this.lines = [...state.lines];
        this.cursorX = state.cursorX;
        this.cursorY = state.cursorY;
        this.offsetX = state.offsetX;
        this.offsetY = state.offsetY;
        this.monoPos = state.monoPos;
        this.checkModified();
    }

    private redo() {
        if (this.redoStack.length === 0) return;
        this.undoStack.push({
            lines: [...this.lines],
            cursorX: this.cursorX,
            cursorY: this.cursorY,
            offsetX: this.offsetX,
            offsetY: this.offsetY,
            monoPos: this.monoPos
        });
        const state = this.redoStack.pop()!;
        this.lines = [...state.lines];
        this.cursorX = state.cursorX;
        this.cursorY = state.cursorY;
        this.offsetX = state.offsetX;
        this.offsetY = state.offsetY;
        this.monoPos = state.monoPos;
        this.checkModified();
    }

    private checkModified() {
        if (this.lines.length !== this.originalLines.length) {
            this.changed = true;
            return;
        }
        for (let i = 0; i < this.lines.length; i++) {
            if (this.lines[i] !== this.originalLines[i]) {
                this.changed = true;
                return;
            }
        }
        this.changed = false;
    }

    /**
     * SEARCH & REPLACE
     */
    private async startFindMode(isReplace: boolean = false) {
        this.findMode = true;
        this.replaceMode = isReplace;
        this.findStep = "find";
        this.findText = "";
        this.replaceText = "";
        this.findResults = [];
        this.findCurrentIndex = -1;
        await this.renderStatusBar();
    }

    private performFind() {
        if (!this.findText) return;
        this.findResults = [];
        const isCaseSensitive = /[A-Z]/.test(this.findText);
        const searchStr = isCaseSensitive ? this.findText : this.findText.toLowerCase();

        for (let i = 0; i < this.lines.length; i++) {
            const line = (isCaseSensitive ? this.lines[i] : this.lines[i].toLowerCase());
            let pos = line.indexOf(searchStr);
            while (pos !== -1) {
                this.findResults.push({ line: i, col: pos, length: this.findText.length });
                pos = line.indexOf(searchStr, pos + 1);
            }
        }
    }

    private async replaceAll() {
        if (this.findResults.length === 0) return;
        this.captureState(true);
        // Reverse to maintain offsets
        for (let i = this.findResults.length - 1; i >= 0; i--) {
            const res = this.findResults[i];
            const line = this.lines[res.line];
            this.lines[res.line] = line.slice(0, res.col) + this.replaceText + line.slice(res.col + res.length);
        }
        this.changed = true;
        this.checkModified();
        await this.render();
        await this.os.std.print(`\x1b[${this.screenHeight + 1};1H\x1b[42m\x1b[30m Replaced ${this.findResults.length} occurrences. \x1b[0m\x1b[K`);
        setTimeout(() => this.renderStatusBar(), 1500);
    }

    private async findNext() {
        if (this.findResults.length === 0) return;
        this.findCurrentIndex = (this.findCurrentIndex + 1) % this.findResults.length;
        await this.jumpToResult(this.findCurrentIndex);
    }

    private async jumpToResult(index: number) {
        const res = this.findResults[index];
        this.cursorX = res.col;
        this.monoPos = this.cursorX;
        const targetLine = res.line;

        if (targetLine < this.offsetY || targetLine >= this.offsetY + this.screenHeight) {
            this.offsetY = Math.max(0, targetLine - Math.floor(this.screenHeight / 2));
        }
        this.cursorY = targetLine - this.offsetY;

        await this.adjustHorizontalScroll();
        await this.render();
    }

    /**
     * PROMPTS & HELP
     */
    private async askDirtyExit(): Promise<"save" | "discard" | "cancel"> {
        const prompt = "File modified. (S)ave, (D)iscard, (C)ancel? ";
        await this.os.std.print(`\x1b[${this.screenHeight + 1};1H\x1b[43m\x1b[30m ${prompt} \x1b[0m\x1b[K`);
        while (true) {
            const char = (await this.os.std.getChar()).toLowerCase();
            if (char === "s") return "save";
            if (char === "d") return "discard";
            if (char === "c" || char === "\u001b") return "cancel";
        }
    }

    private async showHelp() {
        const helpText = [
            "┌─────────────────────────────────────────────────────────────┐",
            "│                   ATTO Text Editor help                     │",
            "├─────────────────────────────────────────────────────────────┤",
            "│ Ctrl+S: Save       │ Ctrl+F: Find        │ Ctrl+L: Find Next│",
            "│ Ctrl+W: Save & Exit│ Alt+R : Replace     │ F1    : Help     │",
            "│ Ctrl+C: Exit       │ Ctrl+Z: Undo        │ Arrows: Nav      │",
            "├─────────────────────────────────────────────────────────────┤",
            "│              Press any key to continue...                   │",
            "└─────────────────────────────────────────────────────────────┘"
        ];
        const startRow = Math.max(1, Math.floor((this.screenHeight - helpText.length) / 2));
        const startCol = Math.max(1, Math.floor((this.screenWidth - 63) / 2));

        let output = "\x1b[?25l";
        for (let i = 0; i < helpText.length; i++) {
            output += `\x1b[${startRow + i};${startCol}H\x1b[1;37;44m${helpText[i]}\x1b[0m`;
        }
        await this.os.std.print(output);
        await this.os.std.getChar();
        await this.render();
    }

    public async save() {
        try {
            const content = this.lines.join("\n");
            const fd = await this.os.fs.open(this.filename);
            if (fd !== null) {
                await this.os.fs.write(fd, content);
                await this.os.fs.close(fd);
                this.changed = false;
                this.originalLines = [...this.lines];
                await this.render();
                await this.os.std.print(`\x1b[${this.screenHeight + 1};1H\x1b[42m\x1b[30m ** File Saved! ** \x1b[0m\x1b[K`);
                setTimeout(() => this.renderStatusBar(), 1500);
            }
        } catch (e: any) {
            await this.os.std.print(`\x1b[${this.screenHeight + 1};1H\x1b[41m\x1b[37m Error: ${e.message} \x1b[0m\x1b[K`);
        }
    }
}

export class main implements IProgram {
    async execute(os: OSContext, args: string[]): Promise<void> {
        if (args.length < 1) {
            await os.std.print("Usage: atto <filename>\n");
            return;
        }

        const filename = args[0];
        let content = "";
        try {
            const fd = await os.fs.open(filename);
            if (fd !== null) {
                content = await os.fs.read(fd);
                await os.fs.close(fd);
            }
        } catch (e) { }

        const editor = new SimpleTextEditor(content, os, filename);
        await editor.init();
        await os.std.setRawMode(true);
        await os.std.print("\x1B[H\x1B[J");

        try {
            await editor.render();
            while (true) {
                const char = await os.std.getChar();
                const result = await editor.handleKey(char);
                if (result === "exit") break;
            }
        } finally {
            await os.std.print("\x1B[H\x1B[J");
            await os.std.setRawMode(false);
        }
    }
}
