import { UserLib } from "@tsix/UserLib";

export default class IPCListener {
    async execute(lib: UserLib, args: string[]) {
        const pid = lib.getPid();
        await lib.std.println(`[Listener] I am PID: ${pid}`);
        await lib.std.println(`[Listener] Waiting for horizontal IPC messages...`);
        await lib.std.println(`[Listener] Run 'pusher.ts ${pid} "hello"' to send a message.`);

        lib.onEvent("ipc_message", (packet: any) => {
            const { fromPid, fromUser, data } = packet;
            lib.std.println(`\n[IPC] Message received!`);
            lib.std.println(`From : ${fromUser} (PID ${fromPid})`);
            lib.std.println(`Data : ${JSON.stringify(data)}`);
            lib.std.print(`[Listener] Continuing to wait...\n> `);
        });

        // Keep the process alive
        while (true) {
            await new Promise(r => setTimeout(r, 1000));
        }
    }
}
