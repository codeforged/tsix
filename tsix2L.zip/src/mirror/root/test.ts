import { Program, std, shell } from "@tsix/Application";

export const main = Program(async () => {
    let loopExit = false;
    shell.onSignal("SIGINT", async () => {
        await std.println("Kami keluar dengan damai");
        loopExit = true;
    });
    while (!loopExit) {
        const millis = await std.millis();
        await std.println(`[${millis}] Hello World! 🔥 (Pausable Loop) 123`);
        if (!loopExit) await std.sleep(1000);
    }
    await shell.exit(0);
});