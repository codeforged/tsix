import { IProgram, OSContext } from "../lib/IProgram";

/**
 * ATTO Text Editor
 * Ported from NOS for TSIX.
 * Robust implementation matching texteditor.js logic.
 */

interface EditorState {
    lines: string[];
    cursorX: number;
    cursorY: number;
    offsetX: number;
    offsetY: number;
    monoPos: number;
}

class SimpleTextEditor {
    public lines: string[];
    public cursorX: number = 0;
    public cursorY: number = 0;
    public offsetX: number = 0;
    public offsetY: number = 0;
    public monoPos: number = 0;
    public screenWidth: number = 80;
    public screenHeight: number = 23;
    public changed: boolean = false;
    public filename: string;
    private os: OSContext;

    private originalLines: string[] = [];

    // Search & Replace state
    public findMode: boolean = false;
    private findText: string = "";
    private replaceMode: boolean = false;
    private replaceText: string = "";
    private findResults: { line: number, col: number, length: number }[] = [];
    private findCurrentIndex: number = -1;
    private findStep: "find" | "replace" | "confirm" = "find";

    private undoStack: EditorState[] = [];
    private redoStack: EditorState[] = [];
    private maxHistorySize: number = 50;
    private lastEditLine: number = -1;
    private lastEditCol: number = -1;
    private lastIpcMessage: string = "";
    private scrollPos: number = 0;
    private scrollInterval: any = null;
    private isScrolling: boolean = false;


    constructor(content: string, os: OSContext, filename: string) {
        this.os = os;
        this.filename = filename;
        // Strip carriage returns and expand tabs
        const safeContent = (content || "").toString();
        const cleanedContent = safeContent.replace(/\r/g, "").replace(/\t/g, "  ");
        this.lines = cleanedContent ? cleanedContent.split("\n") : [""];
        this.originalLines = [...this.lines];
    }

    public async init() {
        // Read from environment variables if possible
        const envLines = parseInt(await this.os.shell.getenv("LINES") || "24");
        const envColumns = parseInt(await this.os.shell.getenv("COLUMNS") || "80");

        const screen = await this.os.std.getScreenInfo() || { lines: envLines, columns: envColumns };
        this.screenWidth = screen.columns;
        this.screenHeight = screen.lines - 1; // Reserve 1 for status bar

        // Listen for window resize signal
        this.os.shell.onSignal("SIGWINCH", async () => {
            const envLines = parseInt(await this.os.shell.getenv("LINES") || "24");
            const envColumns = parseInt(await this.os.shell.getenv("COLUMNS") || "80");
            const newScreen = await this.os.std.getScreenInfo() || { lines: envLines, columns: envColumns };
            this.screenWidth = newScreen.columns;
            this.screenHeight = newScreen.lines - 1;
            await this.render();
        });

        // Listen for SIGINT (Ctrl+C) - Just the claim to prevent default exit
        this.os.shell.onSignal("SIGINT", async () => {
            // Signal received, we rely on the character \u0003 appearing in stdin
            // which is pushed by KeyboardDevice.
        });

        // Disable Line Wrapping for perfect TUI positioning
        await this.write("\x1b[?7l");

        // Listen to IPC messages
        const lib = (this.os.std as any)._lib;
        if (lib && lib.onEvent) {
            lib.onEvent("ipc_message", (msg: any) => {
                this.lastIpcMessage = msg.data.text || "";
                this.scrollPos = 0;
                this.renderStatusBar();
            });
        }

        // Setup scrolling animation timer
        this.scrollInterval = setInterval(() => {
            if (this.lastIpcMessage && this.isScrolling && !this.findMode) {
                this.scrollPos++;
                this.renderStatusBar();
            }
        }, 150);
    }

    /**
     * RENDER UI
     */
    private async write(text: string) {
        await this.os.fs.write(1, text);
    }

    /**
     * RENDER UI
     */
    public async render() {
        const visibleLines = this.lines.slice(this.offsetY, this.offsetY + this.screenHeight);

        let output = "\x1B[?25l"; // Hide cursor
        for (let i = 0; i < this.screenHeight; i++) {
            const lineIdx = this.offsetY + i;
            output += `\x1b[${i + 1};1H\x1b[2K`;

            if (lineIdx < this.lines.length) {
                const line = this.lines[lineIdx];
                const displayLine = line.slice(this.offsetX, this.offsetX + this.screenWidth);
                output += displayLine;
                if (line.length > this.offsetX + this.screenWidth) {
                    output += `\x1b[${i + 1};${this.screenWidth}H→`;
                }
            } else {
                // Blue Tilde for empty lines beyond EOF
                output += `\x1b[34m~\x1b[0m`;
            }
        }

        await this.write(output);
        await this.renderStatusBar();
        await this.renderCursorOnly();
    }

    public async renderCurrentLine() {
        const lineIdx = this.cursorY + this.offsetY;
        const line = this.lines[lineIdx] || "";
        const displayLine = line.slice(this.offsetX, this.offsetX + this.screenWidth);

        // Move to start of line, clear it, write text
        let output = `\x1b[${this.cursorY + 1};1H\x1b[2K${displayLine}`;

        // Handle "→" indicator if line exceeds viewport
        if (line.length > this.offsetX + this.screenWidth) {
            output += `\x1b[${this.cursorY + 1};${this.screenWidth}H→`;
        }

        await this.write(output);
        await this.renderCursorOnly();
    }

    public async renderStatusBar() {
        if (this.findMode) {
            let prompt = "";
            let info = "";
            if (this.findResults.length > 0) {
                info = ` [${this.findCurrentIndex + 1}/${this.findResults.length}]`;
            }

            if (this.findStep === "find") prompt = `Find: ${this.findText}${info}`;
            else if (this.findStep === "replace") prompt = `Replace with: ${this.replaceText}${info}`;
            else if (this.findStep === "confirm") prompt = `Replace? (y)es (n)o (a)ll (q)uit${info}`;

            const padding = " ".repeat(Math.max(0, this.screenWidth - prompt.length));
            await this.write(`\x1b[${this.screenHeight + 1};1H\x1b[7m${prompt}${padding}\x1b[0m`);
            await this.positionCursorInternal();
            return;
        }

        const totalLines = this.lines.length;
        const currentLine = this.cursorY + this.offsetY + 1;
        const currentCol = this.cursorX + 1;
        const modified = this.changed ? " [Modified]" : "";

        const leftText = ` R:${currentLine}/${totalLines} C:${currentCol}${modified} `;
        const rightText = ` ${this.filename} `;

        let centerText = "";
        const msg = this.lastIpcMessage || "";
        const scrollWidth = 40;
        if (!msg) {
            centerText = " ".repeat(scrollWidth);
        } else {
            if (this.isScrolling) {
                const gap = "        ";
                const fullStr = msg + gap;
                const pos = this.scrollPos % fullStr.length;
                let repeated = fullStr;
                while (repeated.length < pos + scrollWidth) repeated += fullStr;
                centerText = repeated.slice(pos, pos + scrollWidth);
            } else {
                centerText = msg;
            }
        }

        if (this.findResults.length > 0) {
            centerText = ` [Match ${this.findCurrentIndex + 1}/${this.findResults.length}] `.padEnd(40);
        }

        const totalUsed = leftText.length + rightText.length + centerText.length;
        const totalPadding = Math.max(0, this.screenWidth - totalUsed);
        const padLeftCount = Math.floor(totalPadding / 2);
        const padLeft = " ".repeat(padLeftCount);
        const padRight = " ".repeat(totalPadding - padLeftCount);

        const statusOutput = `\x1b[${this.screenHeight + 1};1H\x1b[7m${leftText}${padLeft}${centerText}${padRight}${rightText}\x1b[0m`;
        await this.write(statusOutput);
        await this.positionCursorInternal();
    }

    public async renderCursorOnly() {
        await this.renderStatusBar();
    }

    private async positionCursorInternal() {
        if (this.findMode) {
            let cursorCol = 1;
            if (this.findStep === "find") cursorCol = 7 + this.findText.length;
            else if (this.findStep === "replace") cursorCol = 15 + this.replaceText.length;
            else if (this.findStep === "confirm") {
                const res = this.findResults[this.findCurrentIndex];
                cursorCol = Math.max(0, Math.min(this.screenWidth - 1, res.col - this.offsetX)) + 1;
                await this.write(`\x1b[${this.cursorY + 1};${cursorCol}H\x1B[?25h`);
                return;
            }
            await this.write(`\x1b[${this.screenHeight + 1};${cursorCol}H\x1B[?25h`);
            return;
        }
        const displayCursorX = Math.max(0, Math.min(this.screenWidth, this.cursorX - this.offsetX));
        await this.write(`\x1b[${this.cursorY + 1};${displayCursorX + 1}H\x1B[?25h`);
    }

    /**
     * INPUT HANDLING
     */
    public async handleKey(char: string): Promise<string | void> {
        const { std } = this.os;

        // 1. ESCAPE SEQUENCES (Arrows, Home, End, etc.)
        // 1. ESCAPE SEQUENCES (Arrows, Home, End, etc.)
        if (char === "\u001b") {
            // Robust check for sequence: poll several times with small delays
            let seq1: string | null = null;
            for (let i = 0; i < 5; i++) {
                seq1 = await std.poll();
                if (seq1) break;
                await new Promise(r => setTimeout(r, 20));
            }

            if (seq1 === "[") {
                await std.getChar(); // consume [
                const seq2 = await std.getChar();
                if (seq2 === "A") { await this.moveUp(); return; }
                if (seq2 === "B") { await this.moveDown(); return; }
                if (seq2 === "C") { await this.moveRight(); return; }
                if (seq2 === "D") { await this.moveLeft(); return; }
                if (seq2 === "H") {
                    this.cursorX = 0; this.monoPos = 0;
                    if (!(await this.adjustHorizontalScroll())) await this.renderCursorOnly();
                    return;
                }
                if (seq2 === "F") { await this.jumpToEnd(); return; }
                if (seq2 === "5") { await std.getChar(); await this.pageUp(); return; } // \u001b[5~
                if (seq2 === "6") { await std.getChar(); await this.pageDown(); return; } // \u001b[6~
                if (seq2 === "3") { await std.getChar(); await this.deleteChar(); return; } // \u001b[3~

                if (seq2 === "1") {
                    const seq3 = await std.getChar();
                    if (seq3 === ";") {
                        const seq4 = await std.getChar();
                        if (seq4 === "5") {
                            const seq5 = await std.getChar();
                            if (seq5 === "C") { await this.jumpToNextWord(); return; }
                            if (seq5 === "D") { await this.jumpToPrevWord(); return; }
                            if (seq5 === "A") { for (let k = 0; k < 5; k++) await this.moveUp(); return; }
                            if (seq5 === "B") { for (let k = 0; k < 5; k++) await this.moveDown(); return; }
                            if (seq5 === "H") { await this.jumpToStartOfFile(); return; } // Ctrl+Home
                            if (seq5 === "F") { await this.jumpToEndOfFile(); return; }   // Ctrl+End
                        }
                    } else if (seq3 === "~") {
                        this.cursorX = 0; this.monoPos = 0;
                        if (!(await this.adjustHorizontalScroll())) await this.renderCursorOnly();
                        return;
                    }
                }
            } else if (seq1 === "O") {
                await std.getChar(); // consume O
                const seq2 = await std.getChar();
                if (seq2 === "P") { await this.showHelp(); return; } // F1
                if (seq2 === "Q") return; // F2
                if (seq2 === "R") return; // F3
                if (seq2 === "S") return; // F4
                if (seq2 === "H") { this.cursorX = 0; this.monoPos = 0; if (!(await this.adjustHorizontalScroll())) await this.renderCursorOnly(); return; }
                if (seq2 === "F") { await this.jumpToEnd(); return; }
            } else if (seq1 === "r") {
                await std.getChar(); // consume r
                await this.startFindMode(true);
                return;
            }

            // Literal ESC or unknown sequence
            if (this.findMode) {
                this.findMode = false;
                this.replaceMode = false;
                await this.render();
                return;
            }

            // Only trigger find if it was a literal ESC (no sequence followed after delay)
            if (!seq1) {
                await this.startFindMode(false);
            }
            return;
        }

        // 2. SEARCH MODE INPUT
        if (this.findMode) {
            if (char === "\r" || char === "\n") {
                if (this.findStep === "find") {
                    if (this.findText) {
                        this.performFind();
                        if (this.findResults.length > 0) {
                            if (this.replaceMode) {
                                this.findStep = "replace";
                                await this.renderStatusBar();
                            } else {
                                this.findMode = false;
                                await this.jumpToResult(0);
                            }
                        } else {
                            await this.write(`\x1b[${this.screenHeight + 1};1H\x1b[41m\x1b[97m No results found for "${this.findText}" \x1b[0m\x1b[K`);
                            setTimeout(() => this.renderStatusBar(), 2000);
                        }
                    } else {
                        this.findMode = false;
                        await this.render();
                    }
                } else if (this.findStep === "replace") {
                    this.findStep = "confirm";
                    this.findCurrentIndex = 0;
                    await this.jumpToResult(0);
                }
                return;
            }

            if (this.findStep === "confirm") {
                const c = char.toLowerCase();
                if (c === "y") {
                    await this.replaceCurrent();
                    if (this.findResults.length > 0) {
                        this.findCurrentIndex %= this.findResults.length;
                        await this.jumpToResult(this.findCurrentIndex);
                    } else {
                        this.findMode = false;
                        await this.render();
                    }
                } else if (c === "n") {
                    this.findCurrentIndex = (this.findCurrentIndex + 1) % this.findResults.length;
                    await this.jumpToResult(this.findCurrentIndex);
                } else if (c === "a") {
                    await this.replaceAll();
                    this.findMode = false;
                } else if (c === "q") {
                    this.findMode = false;
                    await this.render();
                }
                return;
            }

            if (char === "\u007f" || char === "\b") {
                if (this.findStep === "find") {
                    this.findText = this.findText.slice(0, -1);
                    this.performFind();
                }
                else if (this.findStep === "replace") this.replaceText = this.replaceText.slice(0, -1);
                await this.renderStatusBar();
            } else if (char >= " ") {
                if (this.findStep === "find") {
                    this.findText += char;
                    this.performFind();
                }
                else if (this.findStep === "replace") this.replaceText += char;
                await this.renderStatusBar();
            }
            return;
        }

        // 3. GLOBAL SHORTCUTS
        if (char === "\u0001") { this.cursorX = 0; this.monoPos = 0; if (!(await this.adjustHorizontalScroll())) await this.renderCursorOnly(); return; } // Ctrl+A
        if (char === "\u0005") { await this.jumpToEnd(); return; } // Ctrl+E
        if (char === "\u0006") { await this.startFindMode(false); return; } // Ctrl+F
        if (char === "\u000c") { await this.findNext(); return; }           // Ctrl+L
        if (char === "\u0012") { await this.startFindMode(true); return; }  // Ctrl+R
        if (char === "\u000b") { await this.deleteLine(); return; }         // Ctrl+K
        if (char === "\u0013") { await this.save(); return; }               // Ctrl+S
        if (char === "\u001a") { this.undo(); await this.render(); return; } // Ctrl+Z
        if (char === "\u0019") { this.redo(); await this.render(); return; } // Ctrl+Y
        if (char === "\u0014") { this.isScrolling = !this.isScrolling; await this.renderStatusBar(); return; } // Ctrl+T

        if (char === "\u0017" || char === "\u0003") { // Ctrl+W or Ctrl+C: Exit
            this.checkModified();
            if (this.changed) {
                const choice = await this.askDirtyExit();
                if (choice === "save") {
                    await this.save();
                    return "exit";
                }
                if (choice === "discard") return "exit";
                // Cancel
                await this.render();
                return;
            } else {
                return "exit";
            }
        }

        // 4. REGULAR EDITING
        if (char === "\t") {
            char = "  "; // Convert tab to 2 spaces
        }

        if (char === "\r" || char === "\n") {
            this.captureState(true);
            const lineIdx = this.cursorY + this.offsetY;
            const line = this.lines[lineIdx] || "";
            this.lines.splice(lineIdx + 1, 0, line.slice(this.cursorX));
            this.lines[lineIdx] = line.slice(0, this.cursorX);
            this.cursorX = 0;
            this.offsetX = 0;
            this.monoPos = 0;
            if (this.cursorY < this.screenHeight - 1) this.cursorY++;
            else this.offsetY++;
            this.changed = true;
            this.checkModified();
            await this.render();
        } else if (char === "\u007f" || char === "\b") {
            await this.backspace();
            if (!(await this.adjustHorizontalScroll())) {
                await this.renderCurrentLine();
            }
        } else if (char >= " ") {
            this.captureState();
            const lineIdx = this.cursorY + this.offsetY;
            const line = this.lines[lineIdx] || "";
            this.lines[lineIdx] = line.slice(0, this.cursorX) + char + line.slice(this.cursorX);
            this.cursorX += char.length;
            this.changed = true;
            this.monoPos = this.cursorX;
            this.checkModified();

            if (!(await this.adjustHorizontalScroll())) {
                await this.renderCurrentLine();
            }
        }
    }

    /**
     * NAVIGATION
     */
    private async moveUp() {
        if (this.cursorY > 0) {
            this.cursorY--;
        } else if (this.offsetY > 0) {
            this.offsetY--;
            await this.render();
        }
        const line = this.lines[this.cursorY + this.offsetY] || "";
        this.cursorX = Math.min(this.monoPos, line.length);
        if (!(await this.adjustHorizontalScroll())) {
            await this.renderCursorOnly();
        }
    }

    private async moveDown() {
        if (this.cursorY < this.screenHeight - 1 && this.cursorY + this.offsetY < this.lines.length - 1) {
            this.cursorY++;
        } else if (this.offsetY + this.screenHeight < this.lines.length) {
            this.offsetY++;
            await this.render();
        }
        const line = this.lines[this.cursorY + this.offsetY] || "";
        this.cursorX = Math.min(this.monoPos, line.length);
        if (!(await this.adjustHorizontalScroll())) {
            await this.renderCursorOnly();
        }
    }

    private async moveLeft() {
        if (this.cursorX > 0) {
            this.cursorX--;
            this.monoPos = this.cursorX;
            if (!(await this.adjustHorizontalScroll())) {
                await this.renderCursorOnly();
            }
        } else if (this.cursorY + this.offsetY > 0) {
            await this.moveUp();
            this.cursorX = this.lines[this.cursorY + this.offsetY].length;
            this.monoPos = this.cursorX;
            if (!(await this.adjustHorizontalScroll())) {
                await this.render();
            }
        }
    }

    private async moveRight() {
        const line = this.lines[this.cursorY + this.offsetY] || "";
        if (this.cursorX < line.length) {
            this.cursorX++;
            this.monoPos = this.cursorX;
            if (!(await this.adjustHorizontalScroll())) {
                await this.renderCursorOnly();
            }
        } else if (this.cursorY + this.offsetY < this.lines.length - 1) {
            await this.moveDown();
            this.cursorX = 0;
            this.offsetX = 0;
            this.monoPos = 0;
            await this.render();
        }
    }

    private async jumpToHome() {
        this.cursorX = 0;
        this.offsetX = 0;
        this.monoPos = 0;
        if (!(await this.adjustHorizontalScroll())) {
            await this.renderCursorOnly();
        }
    }

    private async jumpToEnd() {
        const line = this.lines[this.cursorY + this.offsetY] || "";
        this.cursorX = line.length;
        this.monoPos = this.cursorX;
        if (!(await this.adjustHorizontalScroll())) {
            await this.render();
        }
    }

    private async pageUp() {
        this.offsetY = Math.max(0, this.offsetY - this.screenHeight);
        await this.render();
    }

    private async pageDown() {
        if (this.offsetY + this.screenHeight < this.lines.length) {
            this.offsetY = Math.min(this.lines.length - this.screenHeight, this.offsetY + this.screenHeight);
            await this.render();
        }
    }

    private async jumpToNextWord() {
        const line = this.lines[this.cursorY + this.offsetY] || "";
        if (this.cursorX >= line.length) {
            if (this.cursorY + this.offsetY < this.lines.length - 1) {
                await this.moveDown();
                this.cursorX = 0;
                this.monoPos = 0;
                await this.render();
            }
            return;
        }
        let pos = this.cursorX;
        const isAlphanum = (c: string) => /[a-zA-Z0-9]/.test(c);
        if (isAlphanum(line[pos])) {
            while (pos < line.length && isAlphanum(line[pos])) pos++;
        }
        while (pos < line.length && !isAlphanum(line[pos])) pos++;
        this.cursorX = pos;
        this.monoPos = pos;
        if (!(await this.adjustHorizontalScroll())) {
            await this.render();
        }
    }

    private async jumpToPrevWord() {
        if (this.cursorX === 0) {
            if (this.cursorY + this.offsetY > 0) {
                await this.moveUp();
                this.cursorX = this.lines[this.cursorY + this.offsetY].length;
                this.monoPos = this.cursorX;
                await this.render();
            }
            return;
        }
        const line = this.lines[this.cursorY + this.offsetY] || "";
        let pos = this.cursorX - 1;
        const isAlphanum = (c: string) => /[a-zA-Z0-9]/.test(c);
        while (pos > 0 && !isAlphanum(line[pos])) pos--;
        while (pos > 0 && isAlphanum(line[pos - 1])) pos--;
        this.cursorX = pos;
        this.monoPos = pos;
        if (!(await this.adjustHorizontalScroll())) {
            await this.render();
        }
    }

    private async jumpToStartOfFile() {
        this.cursorX = 0;
        this.cursorY = 0;
        this.offsetX = 0;
        this.offsetY = 0;
        this.monoPos = 0;
        await this.render();
    }

    private async jumpToEndOfFile() {
        this.offsetY = Math.max(0, this.lines.length - this.screenHeight);
        this.cursorY = Math.min(this.lines.length - this.offsetY - 1, this.screenHeight - 1);
        const line = this.lines[this.lines.length - 1] || "";
        this.cursorX = line.length;
        this.monoPos = this.cursorX;
        if (!(await this.adjustHorizontalScroll())) {
            await this.render();
        }
    }

    private async adjustHorizontalScroll(): Promise<boolean> {
        if (this.cursorX < this.offsetX) {
            this.offsetX = this.cursorX;
            await this.render();
            return true;
        } else if (this.cursorX >= this.offsetX + this.screenWidth) {
            this.offsetX = this.cursorX - this.screenWidth + 1;
            await this.render();
            return true;
        }
        return false;
    }

    /**
     * EDITING ACTIONS
     */
    private async backspace() {
        if (this.cursorX > 0) {
            this.captureState();
            const lineIdx = this.cursorY + this.offsetY;
            const line = this.lines[lineIdx];
            this.lines[lineIdx] = line.slice(0, this.cursorX - 1) + line.slice(this.cursorX);
            this.cursorX--;
            this.changed = true;
            this.monoPos = this.cursorX;
            this.checkModified();
            await this.adjustHorizontalScroll();
        } else if (this.cursorY + this.offsetY > 0) {
            this.captureState();
            const currentLineIdx = this.cursorY + this.offsetY;
            const prevLineIdx = currentLineIdx - 1;
            const prevLine = this.lines[prevLineIdx];
            this.cursorX = prevLine.length;
            this.lines[prevLineIdx] = prevLine + this.lines[currentLineIdx];
            this.lines.splice(currentLineIdx, 1);
            if (this.cursorY > 0) this.cursorY--;
            else this.offsetY--;
            this.changed = true;
            this.monoPos = this.cursorX;
            this.checkModified();
            await this.adjustHorizontalScroll();
        }
    }

    private async deleteChar() {
        const lineIdx = this.cursorY + this.offsetY;
        const line = this.lines[lineIdx];
        if (this.cursorX < line.length) {
            this.captureState();
            this.lines[lineIdx] = line.slice(0, this.cursorX) + line.slice(this.cursorX + 1);
            this.changed = true;
            this.checkModified();
            await this.render();
        } else if (lineIdx < this.lines.length - 1) {
            this.captureState();
            this.lines[lineIdx] = line + this.lines[lineIdx + 1];
            this.lines.splice(lineIdx + 1, 1);
            this.changed = true;
            this.checkModified();
            await this.render();
        }
    }

    private async deleteLine() {
        this.captureState(true);
        const lineIdx = this.cursorY + this.offsetY;
        this.lines.splice(lineIdx, 1);
        if (this.lines.length === 0) this.lines = [""];
        if (lineIdx >= this.lines.length) {
            if (this.cursorY > 0) this.cursorY--;
            else if (this.offsetY > 0) this.offsetY--;
        }
        this.cursorX = 0;
        this.monoPos = 0;
        this.changed = true;
        this.checkModified();
        await this.render();
    }

    /**
     * STATE MANAGEMENT
     */
    private captureState(force: boolean = false) {
        const currLineIdx = this.cursorY + this.offsetY;
        const currCol = this.cursorX;

        if (!force) {
            if (this.lastEditLine === currLineIdx) {
                const line = this.lines[currLineIdx] || "";
                if (Math.abs(currCol - this.lastEditCol) < 2) {
                    const min = Math.min(this.lastEditCol, currCol);
                    const max = Math.max(this.lastEditCol, currCol);
                    const between = line.substring(min, max);
                    if (between.indexOf(" ") === -1 && between.indexOf("\t") === -1) return;
                }
            }
        }

        this.lastEditLine = currLineIdx;
        this.lastEditCol = currCol;

        if (this.undoStack.length >= this.maxHistorySize) this.undoStack.shift();
        this.undoStack.push({
            lines: [...this.lines],
            cursorX: this.cursorX,
            cursorY: this.cursorY,
            offsetX: this.offsetX,
            offsetY: this.offsetY,
            monoPos: this.monoPos
        });
        this.redoStack = [];
    }

    private undo() {
        if (this.undoStack.length === 0) return;
        this.redoStack.push({
            lines: [...this.lines],
            cursorX: this.cursorX,
            cursorY: this.cursorY,
            offsetX: this.offsetX,
            offsetY: this.offsetY,
            monoPos: this.monoPos
        });
        const state = this.undoStack.pop()!;
        this.lines = [...state.lines];
        this.cursorX = state.cursorX;
        this.cursorY = state.cursorY;
        this.offsetX = state.offsetX;
        this.offsetY = state.offsetY;
        this.monoPos = state.monoPos;
        this.checkModified();
    }

    private redo() {
        if (this.redoStack.length === 0) return;
        this.undoStack.push({
            lines: [...this.lines],
            cursorX: this.cursorX,
            cursorY: this.cursorY,
            offsetX: this.offsetX,
            offsetY: this.offsetY,
            monoPos: this.monoPos
        });
        const state = this.redoStack.pop()!;
        this.lines = [...state.lines];
        this.cursorX = state.cursorX;
        this.cursorY = state.cursorY;
        this.offsetX = state.offsetX;
        this.offsetY = state.offsetY;
        this.monoPos = state.monoPos;
        this.checkModified();
    }

    private checkModified() {
        if (this.lines.length !== this.originalLines.length) {
            this.changed = true;
            return;
        }
        for (let i = 0; i < this.lines.length; i++) {
            if (this.lines[i] !== this.originalLines[i]) {
                this.changed = true;
                return;
            }
        }
        this.changed = false;
    }

    /**
     * SEARCH & REPLACE
     */
    private async startFindMode(isReplace: boolean = false) {
        this.findMode = true;
        this.replaceMode = isReplace;
        this.findStep = "find";
        this.findText = "";
        this.replaceText = "";
        this.findResults = [];
        this.findCurrentIndex = -1;
        await this.renderStatusBar();
    }

    private performFind() {
        if (!this.findText) return;
        this.findResults = [];
        const isCaseSensitive = /[A-Z]/.test(this.findText);
        const searchStr = isCaseSensitive ? this.findText : this.findText.toLowerCase();

        for (let i = 0; i < this.lines.length; i++) {
            const line = (isCaseSensitive ? this.lines[i] : this.lines[i].toLowerCase());
            let pos = line.indexOf(searchStr);
            while (pos !== -1) {
                this.findResults.push({ line: i, col: pos, length: this.findText.length });
                pos = line.indexOf(searchStr, pos + 1);
            }
        }
        if (this.findResults.length > 0) {
            this.findCurrentIndex = 0;
        }
    }

    private async replaceCurrent() {
        if (this.findCurrentIndex === -1 || this.findResults.length === 0) return;
        this.captureState(true);
        const res = this.findResults[this.findCurrentIndex];
        const line = this.lines[res.line];
        this.lines[res.line] = line.slice(0, res.col) + this.replaceText + line.slice(res.col + res.length);
        this.changed = true;
        this.checkModified();

        // Re-calculate find results because positions shifted
        this.performFind();
        // Since we replaced one, we stay at same index (which is now different match)
        // or loop wraps if none left.
        if (this.findResults.length === 0) {
            this.findMode = false;
        }
    }

    private async replaceAll() {
        if (this.findResults.length === 0) return;
        this.captureState(true);
        // Reverse to maintain offsets
        for (let i = this.findResults.length - 1; i >= 0; i--) {
            const res = this.findResults[i];
            const line = this.lines[res.line];
            this.lines[res.line] = line.slice(0, res.col) + this.replaceText + line.slice(res.col + res.length);
        }
        this.changed = true;
        this.checkModified();
        await this.render();
        await this.write(`\x1b[${this.screenHeight + 1};1H\x1b[42m\x1b[30m Replaced ${this.findResults.length} occurrences. \x1b[0m\x1b[K`);
        setTimeout(() => this.renderStatusBar(), 1500);
    }

    private async findNext() {
        if (this.findResults.length === 0) return;
        this.findCurrentIndex = (this.findCurrentIndex + 1) % this.findResults.length;
        await this.jumpToResult(this.findCurrentIndex);
    }

    private async jumpToResult(index: number) {
        this.findCurrentIndex = index;
        const res = this.findResults[index];
        this.cursorX = res.col;
        this.monoPos = this.cursorX;
        const targetLine = res.line;

        if (targetLine < this.offsetY || targetLine >= this.offsetY + this.screenHeight) {
            this.offsetY = Math.max(0, targetLine - Math.floor(this.screenHeight / 2));
        }
        this.cursorY = targetLine - this.offsetY;

        await this.adjustHorizontalScroll();
        await this.render();
    }

    /**
     * PROMPTS & HELP
     */
    public async askDirtyExit(): Promise<"save" | "discard" | "cancel"> {
        const prompt = " File Modified! (S)ave, (D)iscard, (C)ancel? ";
        // Use bright Red background for high visibility
        await this.write(`\x1b[${this.screenHeight + 1};1H\x1b[41m\x1b[37m${prompt}\x1b[0m\x1b[K`);
        while (true) {
            const rawChar = await this.os.std.getChar();
            if (rawChar === null) return "discard";
            const char = rawChar.toLowerCase();
            if (char === "s") return "save";
            if (char === "d") return "discard";
            if (char === "c" || char === "\u001b") return "cancel";
            if (char === "\u0003") return "discard"; // Second Ctrl+C = discard
        }
    }

    private async showHelp() {
        const helpText = [
            "┌─────────────────────────────────────────────────────────────┐",
            "│                   ATTO Text Editor help 1.7                 │",
            "├─────────────────────────────────────────────────────────────┤",
            "│ Ctrl+S: Save       │ Ctrl+F: Find        │ Ctrl+L: Find Next│",
            "│ Ctrl+W: Save & Exit│ Alt+R : Replace     │ F1    : Help     │",
            "│ Ctrl+C: Exit       │ Ctrl+Z: Undo        │ Ctrl+T: Scroll   │",
            "│ Ctrl+K: Delete Line│ Ctrl+Y: Redo        │ Ctrl+←/→: Word   │",
            "├─────────────────────────────────────────────────────────────┤",
            "│              Press any key to continue...                   │",
            "└─────────────────────────────────────────────────────────────┘"
        ];
        const startRow = Math.max(1, Math.floor((this.screenHeight - helpText.length) / 2));
        const startCol = Math.max(1, Math.floor((this.screenWidth - 63) / 2));

        let output = "\x1b[?25l";
        for (let i = 0; i < helpText.length; i++) {
            output += `\x1b[${startRow + i};${startCol}H\x1b[1;37;44m${helpText[i]}\x1b[0m`;
        }
        await this.os.std.print(output);
        await this.os.std.getChar();

        // Flush any trailing escape sequence characters (e.g. if user pressed Arrow/ESC to close help)
        while (await this.os.std.poll()) {
            await this.os.std.getChar();
        }

        await this.render();
    }


    public async save() {
        try {
            const content = this.lines.join("\n");
            const fd = await this.os.fs.open(this.filename, "w");
            if (fd !== null) {
                await this.os.fs.write(fd, content);
                await this.os.fs.close(fd);
                this.changed = false;
                this.originalLines = [...this.lines];
                await this.render();
                await this.write(`\x1b[${this.screenHeight + 1};1H\x1b[42m\x1b[30m ** File Saved! ** \x1b[0m\x1b[K`);
                setTimeout(() => this.renderStatusBar(), 1500);
            }
        } catch (e: any) {
            await this.write(`\x1b[${this.screenHeight + 1};1H\x1b[41m\x1b[37m Error: ${e.message} \x1b[0m\x1b[K`);
        }
    }

    private isExiting: boolean = false;

    public async cleanupAndExit() {
        if (this.isExiting) return;
        this.isExiting = true;

        if (this.scrollInterval) clearInterval(this.scrollInterval);

        // Reset terminal state
        await this.os.fs.write(1, "\x1b[?7h"); // Enable wrap
        await this.os.fs.write(1, "\x1b[?25h"); // Show cursor
        await this.os.fs.write(1, "\x1b[0m");    // Reset colors

        // Clear entire screen and go home
        await this.os.fs.write(1, "\x1b[2J\x1b[H");

        await this.os.std.setRawMode(false);
        await this.os.shell.exit();
    }
}

export class main implements IProgram {
    async execute(os: OSContext, args: string[]): Promise<void> {
        if (args.length < 1) {
            await os.std.print("Usage: atto <filename>\n");
            return;
        }

        const filename = args[0];

        // Register persistent identity
        await os.shell.registerIdentity("a7f7f052-8996-4c5a-a7f0-7ed3469ef53a");

        let content = "";
        try {
            const fd = await os.fs.open(filename);
            if (fd !== null) {
                const rawContent = await os.fs.read(fd);
                content = rawContent || "";
                await os.fs.close(fd);
            }
        } catch (e) { }

        const editor = new SimpleTextEditor(content, os, filename);
        await editor.init();

        await os.std.setRawMode(true);
        await os.std.print("\x1B[H\x1B[J");

        let stop = false;

        // SIGINT HANDLER REMOVED - Using manual Ctrl+C handling in loop to avoid race conditions.

        try {
            await editor.render();
            while (!stop) {
                const char = await os.std.getChar();
                if (char === null) break;
                if (stop) break;
                const result = await editor.handleKey(char);
                if (result === "exit") {
                    stop = true;
                    await editor.cleanupAndExit();
                    break;
                }
            }
        } catch (e) {
            await editor.cleanupAndExit();
        }
    }
}
