/**
 * ps-sample1.ts — PixelSpace Protocol Sample #1 (RAW)
 *
 * ============================================================
 * PENGANTAR PIXELSPACE (Tanpa Window Manager)
 * ============================================================
 *
 * PixelSpace adalah protokol display untuk TSIX (setara X11/Wayland).
 * Ia bekerja dengan DOM-Based Remote Rendering:
 *
 *   ┌──────────┐   GUI_REQ (61)   ┌────────┐   WebSocket   ┌──────────┐
 *   │  Worker   │ ──────────────► │ Kernel │ ────────────► │  Browser │
 *   │  (App)   │ ◄────────────── │ (Ring1)│ ◄──────────── │  (DOME)  │
 *   └──────────┘   IPC via SEND_MSG └────────┘   IBrowserEvent └──────────┘
 *
 * ───────────────────────────────────────────────────────────
 * PENDEKATAN: SUPER RAW — dispatch() langsung, tanpa Emerald
 * ───────────────────────────────────────────────────────────
 *
 * File ini TIDAK mengimpor APAPUN dari @tsix/emerald.
 * Semua komunikasi dilakukan langsung via UserLib.dispatch()
 * dengan payload IGUIPayload mentah.
 *
 * Yang dilakukan:
 *   1. CREATE_WINDOW   → dispatch GUI_REQ → Kernel → DOME → Browser
 *   2. MOUNT_NODE      → kirim node tree ke browser (div, button, text)
 *   3. UPDATE_PROPS    → ubah properti elemen yang sudah di-mount
 *   4. DESTROY_WINDOW  → tutup jendela, bersihkan
 *
 * Untuk event handler: kita pasang listener "ipc_message" via
 * lib.onEvent() — tanpa Window.onClick() dari Emerald.
 *
 * Jalankan:  ps-sample1
 * PASTIKAN DOME SUDAH RUNNING:  dome
 * ============================================================
 */

import { Program, std, shell } from "@tsix/Application";
import { SyscallCode } from "../../common/SyscallCode";
import {
  GUIAction,
  IGUIPayload,
  IDOMNode,
  IGUIEventIPC,
} from "../../common/GUITypes";
import { v4 as uuidv4 } from "uuid";

// ================================================================
// MAIN
// ================================================================

export const appMode = "gui";

export const main = Program(async (args: string[]) => {
  // ----------------------------------------------------------------
  // Dapatkan UserLib untuk dispatch syscall
  // ----------------------------------------------------------------
  const lib = (global as any)._tsixLib;
  if (!lib) {
    await std.error(
      "[ps-sample1] ❌ UserLib not found! Bukan di lingkungan TSIX Worker?",
    );
    return;
  }

  const dispatch = (code: SyscallCode, payload: any) =>
    lib.dispatch(code, payload);
  const pid = lib.getPid();
  const wid = uuidv4();

  // ----------------------------------------------------------------
  // Helper: kirim GUI_REQ payload mentah
  // ----------------------------------------------------------------
  async function guiReq(
    action: GUIAction,
    targetId?: string,
    node?: IDOMNode,
    props?: Record<string, any>,
  ): Promise<any> {
    const payload: IGUIPayload = {
      syscall: "GUI_REQ",
      pid,
      wid,
      action,
      targetId,
      node,
      props,
    };
    return await dispatch(SyscallCode.GUI_REQ, payload);
  }

  // ----------------------------------------------------------------
  // Helper: bikin IDOMNode tanpa factory functions
  // ----------------------------------------------------------------
  function node(
    tag: string,
    props: Record<string, any> = {},
    children: IDOMNode[] = [],
  ): IDOMNode {
    return { id: props.id || uuidv4(), tag, props, children };
  }

  // ----------------------------------------------------------------
  // Helper: notifikasi Asteracea (WM) bahwa window dibuat/ditutup
  // ----------------------------------------------------------------
  // Tanpa ini, WM tidak tahu window kita → tidak ada tombol taskbar.
  // Emerald melakukan ini otomatis via Window.notifyParentWindowCreated().
  async function notifyWm(
    type:
      | "GUI_WINDOW_CREATED"
      | "GUI_WINDOW_CLOSED"
      | "GUI_WINDOW_MINIMIZED"
      | "GUI_WINDOW_RESTORED"
      | "GUI_WINDOW_MAXIMIZED"
      | "GUI_WINDOW_UNMAXIMIZED",
    extra: Record<string, any> = {},
  ): Promise<void> {
    const payload = { type, wid, pid, ...extra };
    try {
      // 1. Kirim ke parent process (jika parent = Asteracea)
      const parentPid = await lib.getParentPid().catch(() => 0);
      if (parentPid) {
        await lib.shell.send(parentPid, payload).catch(() => {});
      }
      // 2. Kirim ke Asteracea WM — untuk app yang di-run via terminal
      //    (PID WM dibaca dari file yang ditulis saat Asteracea startup)
      const wmPidRaw = await lib.fs
        .readFile("/opt/asteracea/wm-pid")
        .catch(() => null);
      if (wmPidRaw) {
        const wmPid = parseInt(String(wmPidRaw).trim());
        if (wmPid && wmPid !== pid && wmPid !== parentPid) {
          await lib.shell.send(wmPid, payload).catch(() => {});
        }
      }
    } catch (_) {
      // WM tidak running — no-op, window tetap berjalan
    }
  }

  // ================================================================
  // 1️⃣ CREATE_WINDOW — bikin surface/panel di browser
  // ================================================================
  // Parameter node dengan tag="window" dan props berisi konfigurasi.
  // DOME akan membuat elemen .tsix-window di browser.
  await std.log("");
  await std.log("▶ [1/5] CREATE_WINDOW");

  await guiReq(
    GUIAction.CREATE_WINDOW,
    undefined,
    node("window", {
      title: "ps-sample1 — Super Raw",
      width: 480,
      height: 320,
      frameless: false,
      resizable: true,
      maximizable: false,
    }),
  );
  await std.log(`  ✓ wid: ${wid}`);

  // Notifikasi Asteracea (WM) → munculkan tombol taskbar
  await notifyWm("GUI_WINDOW_CREATED", {
    title: "ps-sample1 — Super Raw",
    icon: "2️⃣",
  });

  // ================================================================
  // 2️⃣ MOUNT_NODE — pasang elemen ke dalam panel
  // ================================================================
  // mount(parentId=undefined) → targetnya root window/content.
  // Setelah ini, kita mount child ke "root" div.
  await std.log("▶ [2/5] MOUNT_NODE");

  // 2a. Root container — sebuah <div> sebagai panel
  await guiReq(
    GUIAction.MOUNT_NODE,
    undefined,
    node("div", {
      id: "root",
      style: {
        padding: "24px",
        fontFamily: "sans-serif",
        height: "100%",
        boxSizing: "border-box",
      },
    }),
  );

  // 2b. Heading
  await guiReq(
    GUIAction.MOUNT_NODE,
    "root",
    node("p", {
      id: "title",
      text: "⚡ PixelSpace — Super Raw",
      style: {
        fontSize: "20px",
        fontWeight: "bold",
        margin: "0 0 4px 0",
        color: "#ff9800",
      },
    }),
  );

  // 2c. Subtitle
  await guiReq(
    GUIAction.MOUNT_NODE,
    "root",
    node("p", {
      id: "subtitle",
      text: "dispatch() langsung via SyscallCode.GUI_REQ — tanpa Emerald!",
      style: { fontSize: "12px", color: "#888", margin: "0 0 16px 0" },
    }),
  );

  // 2d. Button — onClickId memberitahu DOME agar pasang event listener
  await guiReq(
    GUIAction.MOUNT_NODE,
    "root",
    node("button", {
      id: "btn",
      text: "🔘 Klik Saya!",
      onClickId: "btn",
      style: {
        background: "#ff9800",
        color: "white",
        border: "none",
        padding: "10px 24px",
        borderRadius: "6px",
        cursor: "pointer",
        fontSize: "14px",
        fontWeight: "600",
      },
    }),
  );

  // 2e. Status text
  await guiReq(
    GUIAction.MOUNT_NODE,
    "root",
    node("p", {
      id: "status",
      text: "⏳ Belum diklik",
      style: {
        marginTop: "16px",
        fontSize: "13px",
        color: "#aaa",
        fontStyle: "italic",
      },
    }),
  );

  await std.log("  ✓ root, title, subtitle, button, status");

  // ================================================================
  // 3️⃣ EVENT HANDLER — dengar event dari DOME secara manual
  // ================================================================
  // Karena tanpa Window class, kita harus pasang listener sendiri.
  //
  // Alur event:
  //   Browser klik → DOME (WebSocket) → Kernel (SEND_MSG)
  //   → Worker → lib.onEvent("ipc_message", handler)
  //
  // Format event yang sampai:
  //   IGUIEventIPC { type: "GUI_EVENT", wid, targetId, eventType, value? }
  await std.log("▶ [3/5] Event listener (manual via lib.onEvent)");

  let running = true;

  lib.onEvent("ipc_message", (msg: any) => {
    // SEND_MSG membungkus data di { fromPid, fromUser, data }
    const event: IGUIEventIPC = msg?.data || msg;
    if (!event || event.type !== "GUI_EVENT") return;
    if (event.wid !== wid) return; // Abaikan event untuk window lain

    // ── Klik button ──
    if (event.eventType === "click" && event.targetId === "btn") {
      std.log("  ✦ Event click diterima!").catch(() => {});

      // UPDATE_PROPS — tanpa batching, kirim langsung
      guiReq(GUIAction.UPDATE_PROPS, "btn", undefined, {
        text: "✅ Sudah Diklik!",
        style: {
          background: "#2196f3",
          color: "white",
          border: "none",
          padding: "10px 24px",
          borderRadius: "6px",
          cursor: "pointer",
          fontSize: "14px",
          fontWeight: "600",
        },
      }).catch(() => {});

      guiReq(GUIAction.UPDATE_PROPS, "status", undefined, {
        text: "✅ Diklik! Event via IPC manual.",
        style: {
          marginTop: "16px",
          fontSize: "13px",
          color: "#ff9800",
          fontWeight: "bold",
        },
      }).catch(() => {});
    }

    // ── Tutup window dari browser ──
    if (event.targetId === "__window__" && event.eventType === "close_window") {
      running = false;
    }

    // ── Minimize/Restore dari WM (klik tombol taskbar) atau chrome DOME ──
    if (event.targetId === "__window__") {
      if (event.eventType === "minimize_window") {
        // Sembunyikan window via DOME + beri tahu WM agar state & style
        // tombol taskbar ikut berubah (Asteracea menunggu notifikasi ini)
        guiReq(GUIAction.MINIMIZE_WINDOW).catch(() => {});
        notifyWm("GUI_WINDOW_MINIMIZED").catch(() => {});
      } else if (event.eventType === "restore_window") {
        // Tampilkan lagi window + beri tahu WM → style taskbar aktif kembali
        guiReq(GUIAction.RESTORE_WINDOW).catch(() => {});
        notifyWm("GUI_WINDOW_RESTORED").catch(() => {});
      } else if (event.eventType === "maximize_window") {
        // Maximize (mis. lewat context menu taskbar) + sinkronkan WM
        guiReq(GUIAction.MAXIMIZE_WINDOW).catch(() => {});
        notifyWm("GUI_WINDOW_MAXIMIZED").catch(() => {});
      } else if (event.eventType === "unmaximize_window") {
        // Kembalikan ukuran semula + sinkronkan WM
        guiReq(GUIAction.UNMAXIMIZE_WINDOW).catch(() => {});
        notifyWm("GUI_WINDOW_UNMAXIMIZED").catch(() => {});
      }
    }
  });
  // ================================================================
  // 4️⃣ LOOP — polling sampai window ditutup
  // ================================================================
  await std.log("▶ [4/5] Menunggu... (tutup window untuk exit)");
  while (running) {
    await new Promise((r) => setTimeout(r, 500));
  }

  // await new Promise((r) => setTimeout(r, 3000));

  // ================================================================
  // 5️⃣ DESTROY_WINDOW — cleanup
  // ================================================================
  await std.log("▶ [5/5] DESTROY_WINDOW");
  await notifyWm("GUI_WINDOW_CLOSED"); // hapus tombol taskbar di WM
  await guiReq(GUIAction.DESTROY_WINDOW);
  await std.log("  ✓ Window ditutup.");

  await std.log("");
  await std.log("[ps-sample1] Selesai ✅");
});
