# Changelog Asteracea WM

> Format: `YYYY-MM-DD | Perubahan | Oleh`

---

## 2026-08-08

### Foreign app taskbar button — dukungan custom icon dari payload GUI_WINDOW_CREATED

- **File:** `src/mirror/opt/asteracea/asteracea.ts`
- **Masalah:** Tombol taskbar untuk foreign app (dibuat via `registerForeignApp()`) selalu menampilkan icon `💻` (hardcoded) dan tidak bisa diatur dari sisi aplikasi — tidak seperti app terdaftar di `/opt/asteracea/menu` yang memakai field `icon` dari file `.menu`.
- **Perubahan:**
  - `registerForeignApp()` menerima param baru `icon` (default `"💻"`) → dipakai untuk `entry.icon` dan icon tombol taskbar (`text(icon)`).
  - Handler `GUI_WINDOW_CREATED` meneruskan `payload.icon || "💻"` — foreign app kini bisa mengirim `icon` di notifikasi `GUI_WINDOW_CREATED`.
- **Dampak:** Foreign app (dijalankan dari terminal/shell) bisa menampilkan icon custom di taskbar via payload. Deploy: restart Asteracea.
- **Oleh:** Copilot

## 2026-08-06

### Tooltip taskbar hilang untuk foreign app (tidak terdaftar di /opt/asteracea/menu)

- **File:** `src/mirror/opt/asteracea/asteracea.ts`
- **Masalah:** Taskbar button untuk aplikasi asing (dibuat via `registerForeignApp()` — dijalankan dari terminal/shell, tidak terdaftar di `/opt/asteracea/menu`) tidak menampilkan tooltip, sementara app terdaftar/pinned punya tooltip. Tooltip TSIX adalah sistem custom `data-tt` di DOME client (bukan native `title`), yang di-set dari prop `title` saat taskbar button di-mount.
- **Perubahan:** Tambah prop `title` pada taskbar button di `registerForeignApp()` — nilainya judul window dari payload `GUI_WINDOW_CREATED` (parameter `title`). Konsisten dengan pinned launcher yang memakai `title: app.label`.
- **Dampak:** Semua taskbar button punya tooltip — baik yang terdaftar di menu maupun foreign app. Deploy: restart Asteracea.
- **Oleh:** Copilot

### State WM tidak sinkron setelah maximize lewat context menu taskbar

- **File:** `src/mirror/opt/asteracea/asteracea.ts`
- **Masalah:** Asteracea hanya menangani notifikasi `GUI_WINDOW_MINIMIZED`/`GUI_WINDOW_RESTORED`/`GUI_WINDOW_CLOSED`. Ketika aplikasi di-minimize lalu di-maximize lewat context menu taskbar, notifikasi `GUI_WINDOW_MAXIMIZED` diabaikan → `appState` tetap `MINIMIZED` → klik kiri taskbar berikutnya mengirim `restore_window` (bukan minimize toggle), sehingga perilaku taskbar membingungkan.
- **Perubahan:** Tambah handler `GUI_WINDOW_MAXIMIZED` dan `GUI_WINDOW_UNMAXIMIZED` → `transitionTo(appId, "RUNNING")` + taskbar style aktif (sama seperti `GUI_WINDOW_RESTORED`).
- **Dampak:** State WM sinkron dengan kondisi window; klik taskbar setelah maximize langsung menjadi minimize toggle. Deploy: restart Asteracea.
- **Oleh:** Copilot

---

## 2026-08-04

### Login fix — prefill password `"1"` dihapus

- **File:** `src/mirror/opt/asteracea/asteracea.ts`, `src/mirror/opt/krisan/krisan.ts`
- **Masalah:** Field password login di-prefill `value: "1"` (password default lama) dan bertipe `password` (ter-mask, karakter awal tak terlihat). Setelah `passwd root` mengganti password, nilai terkirim menjadi `"1" + passwordBaru` → `bcrypt.compareSync` selalu false → login selalu ditolak meski password benar (tsh tidak kena karena baca dari terminal tanpa prefill).
- **Perubahan:** Hapus `value: loginPass` dari input password & inisialisasi `loginPass = ""` di `showLoginScreen` (diterapkan juga ke krisan).
- **Dampak:** Field password mulai kosong; password baru diterima apa adanya. (Bug utama tambahan ada di sisi DOME client — lihat changelog `dome.md`.)
- **Oleh:** Copilot

### Wallpaper blank setelah reboot — folder wallpaper dibuat saat runtime

- **File:** `src/mirror/opt/asteracea/asteracea.ts`
- **Masalah:** `showWallpaperDialog` menulis `/opt/asteracea/wallpaper/current-wp.b64` tapi folder `wallpaper/` tidak pernah dibuat → `fs.writeFile` gagal diam-diam → `wallpaper.json` tersimpan tapi file b64 hilang → wallpaper blank setelah reboot.
- **Perubahan:** Tambah `fs.mkdir("/opt/asteracea/wallpaper")` (di-try-catch) sebelum menulis file b64.
- **Dampak:** Wallpaper persist setelah reboot. Catatan: pengaturan lama tersimpan di path `/etc/asteracea/...` → perlu set ulang sekali setelah re-sync.
- **Oleh:** Copilot

### Daemonize — lepas dari console tty1

- **File:** `src/mirror/opt/asteracea/asteracea.ts`
- **Masalah:** Output asteracea menumpuk di console tty1 dan mengganggu user yang mengetik di sana.
- **Perubahan:** `main` diawali `shell.daemonize("Asteracea Window Manager")` (pola sama dengan DOME). Syscall `DETACH` mengalihkan stdio ke `/dev/null` dan melepas foreground TTY. `std.log`/`std.error` tetap masuk `/var/log/syslog` (via VFS, bukan stdout); render GUI tetap via DOME.
- **Dampak:** Console tty1 bersih. Efek samping: run manual dari tsh langsung kembali ke prompt; Ctrl+C tidak mematikan daemon (gunakan `kill <pid>`).
- **Oleh:** Copilot

### Menu & PATH update untuk FHS restructure

- **File:** `src/mirror/opt/asteracea/menu/*.menu`, `src/mirror/etc/profile`
- **Perubahan:** Command menu di-update: app test → `/opt/test/*.js`, app → `/opt/<app>/<app>.js`, tool → `/usr/bin/*.js`, daemon → `/sbin/*`. `profile` menambahkan `/bin:/sbin:/usr/bin:/opt/asteracea:/opt/mysqld:/opt/<app>...` ke PATH.
- **Dampak:** Launcher & shell menemukan binary setelah relokasi FHS.
- **Oleh:** Copilot
